export function utilAlert() {
  document.write("this is a util function<br/>");
}
