# Readings

Useful links / reference / articles

* https://github.com/cwarren/weedstrikeroguelike - demo project
* http://ondras.github.io/rot.js/hp/ - the ROT.js library for building roguelikes in javascript
* https://medium.com/the-node-js-collection/modern-javascript-explained-for-dinosaurs-f695e9747b70 - a guide / tutorial to front-end web development
* https://hackernoon.com/a-map-to-modern-javascript-development-2017-16d9eb86309c - another guide to front-end web development
* https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet - syntax for .md files
* https://hacks.mozilla.org/2015/08/es6-in-depth-modules/ - javascript modules (breakign your codebase into multiple files)
* https://medium.com/javascript-scene/composing-software-an-introduction-27b72500d6ea - function and object composition
