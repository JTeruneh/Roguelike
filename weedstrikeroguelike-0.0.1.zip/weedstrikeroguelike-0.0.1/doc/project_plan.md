# Weed Strike Project Plan

This is the project plan for Weed Strike. This covers general planning thoughts in addition to tasks and milestones. This is NOT a design document for the game.

1. basic design doc for the game
1. trivial game working
1. trivial server-side JS dependency used
